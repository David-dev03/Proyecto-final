# Apuntes-curso-desarrollo-ia
Apuntes curso desarrollo ia mourdev
